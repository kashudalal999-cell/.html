SHEHAB ALI PORTFOLIO

Files:
- index.html: complete responsive portfolio website (HTML, CSS, JavaScript in one file)

Preview:
1. Double-click index.html to open it in your browser.
2. To publish free, create a GitHub repository, upload index.html, then enable Settings > Pages > Deploy from a branch > main > /(root).
3. For a custom domain, buy a domain from a registrar, then add it under GitHub Pages > Custom domain and set the DNS records shown by GitHub. Domain registration is usually paid.
4. Before publishing, replace the sample bio, social profile URLs, projects, and your-email@example.com with your real details.

Contact form note:
The form opens the visitor's email app using a mailto link; it does not send messages directly from the website. For a real hosted form, connect a form service.
